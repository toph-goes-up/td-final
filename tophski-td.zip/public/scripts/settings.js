/**
 * Created by Chris on 4/7/2018.
 */

App.settings = {
    collisionGroupSize: 3,
    nGridCells: 25
};